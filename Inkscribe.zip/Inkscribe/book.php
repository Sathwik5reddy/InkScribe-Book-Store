<?php
session_start();
require_once "./functions/database_functions.php";

if (isset($_POST['submitReview'])) {
    $book_isbn = $_POST['bookisbn'];
    $rating = $_POST['rating'];
    $pros = $_POST['pros'];
    $cons = $_POST['cons'];

    // Connect to the database
    $conn = db_connect();

    // Insert the review into the database using prepared statements
    $insertReviewQuery = "INSERT INTO book_reviews (book_isbn, rating, pros, cons) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $insertReviewQuery);
    mysqli_stmt_bind_param($stmt, "siss", $book_isbn, $rating, $pros, $cons);

    if (mysqli_stmt_execute($stmt)) {
        // Review inserted successfully
        header("Location: book.php?bookisbn=$book_isbn");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}

$book_isbn = $_GET['bookisbn'];

// Connect to the database
$conn = db_connect();

$query = "SELECT * FROM books WHERE book_isbn = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $book_isbn);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
}

$row = mysqli_fetch_assoc($result);
if (!$row) {
    echo "Empty book";
    exit;
}

$title = $row['book_title'];
require "./template/header.php";
?>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <!-- Example row of columns -->
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="books.php" class="text-decoration-none text-muted fw-light">PublBooksishers</a></li>
          <li class="breadcrumb-item active" aria-current="page"><?php echo $row['book_title']; ?></li>
        </ol>
      </nav>
      <div class="row">
        <div class="col-md-3 text-center book-item">
          <div class="img-holder overflow-hidden">
          <img class="img-top" src="./bootstrap/img/<?php echo $row['book_image']; ?>">
          </div>
        </div>
        <div class="col-md-9">
          <div class="card rounded-0 shadow">
            <div class="card-body">
              <div class="container-fluid">
                <h4><?= $row['book_title'] ?></h4>
                <hr>
                  <p><?php echo $row['book_descr']; ?></p>
                  <h4>Details</h4>
                  <table class="table">
                    <?php foreach($row as $key => $value){
                      if($key == "book_descr" || $key == "book_image" || $key == "publisherid" || $key == "book_title"){
                        continue;
                      }
                      switch($key){
                        case "book_isbn":
                          $key = "ISBN";
                          break;
                        case "book_title":
                          $key = "Title";
                          break;
                        case "book_author":
                          $key = "Author";
                          break;
                        case "book_price":
                          $key = "Price";
                          break;
                      }
                    ?>
                    <tr>
                      <td><?php echo $key; ?></td>
                      <td><?php echo $value; ?></td>
                    </tr>
                    <?php 
                      } 
                      if(isset($conn)) {mysqli_close($conn); }
                    ?>
					<tr>
					<td>Rating</td>
					<td><?php
	require_once "./functions/database_functions.php";
    // Connect to the database
    $conn = db_connect();
    // Query to calculate the average rating for the book
    $avgRatingQuery = "SELECT AVG(rating) AS avg_rating FROM book_reviews WHERE book_isbn = '$book_isbn'";
    $avgRatingResult = mysqli_query($conn, $avgRatingQuery);

    if (!$avgRatingResult) {
        echo "Can't retrieve average rating " . mysqli_error($conn);
    } else {
        $avgRatingRow = mysqli_fetch_assoc($avgRatingResult);
        $averageRating = $avgRatingRow['avg_rating'];
        $averageRatingText = number_format($averageRating, 1); // Format the average rating to one decimal point
        ?>
        <?php echo $averageRatingText; ?> out of 5
        <?php
    }
    ?></td>
					</tr>
                  </table>
				  <form method="post" action="cart.php">
                    <input type="hidden" name="bookisbn" value="<?php echo $book_isbn;?>">
                    <div class="text-center">
                    
                      <?php   
                        if ($row['quantity'] <= 0)
                        echo "<input type='submit' value='Out of Stock' name='cart' class='btn btn-danger rounded-0' disabled>";
                        else 
                        echo "<input type='submit' value='Purchase / Add to cart' name='cart' class='btn btn-primary rounded-0'>";

                      ?>
                    

                    </div>
                  </form>
				  <h4>Add Review</h4>
				    <form method="post" action="book.php?bookisbn=<?php echo $book_isbn; ?>">
        <input type="hidden" name="bookisbn" value="<?php echo $book_isbn; ?>">
        <div class="form-group">
            <label for="rating">Rating:</label>
            <select name="rating" id="rating" class="form-control">
                <option value="1">1 Star</option>
                <option value="2">2 Stars</option>
                <option value="3">3 Stars</option>
                <option value="4">4 Stars</option>
                <option value="5">5 Stars</option>
            </select>
        </div>
        <div class="form-group">
            <label for="pros">Pros:</label>
            <textarea name="pros" id="pros" class="form-control" rows="2"></textarea>
        </div>
        <div class="form-group">
            <label for="cons">Cons:</label>
            <textarea name="cons" id="cons" class="form-control" rows="2"></textarea>
        </div>
        <div class="text-center">
            <input type='submit' value='Submit Review' name='submitReview' class='btn btn-danger rounded-0'>
        </div>
    </form>
<h4>All Reviews</h4>
<div class="container">
    <?php
	require_once "./functions/database_functions.php";
    // Query to fetch all reviews for the book
	$conn = db_connect();
    $reviewsQuery = "SELECT * FROM book_reviews WHERE book_isbn = '$book_isbn'";
    $reviewsResult = mysqli_query($conn, $reviewsQuery);

    if (!$reviewsResult) {
        echo "Can't retrieve reviews " . mysqli_error($conn);
    } else {
        while ($review = mysqli_fetch_assoc($reviewsResult)) {
            ?>
            <div class="card mb-3">
                <div class="card-body">
                    <p class="card-text">Rating: <?php echo $review['rating']; ?></p>
                    <p class="card-text"><strong>Pros:</strong> <?php echo $review['pros']; ?></p>
                    <p class="card-text"><strong>Cons:</strong> <?php echo $review['cons']; ?></p>
                </div>
            </div>
            <?php
        }
        mysqli_free_result($reviewsResult);
    }
    ?>
</div>
              </div>
            </div>
          </div>
       	</div>
      </div>
<?php
  require "./template/footer.php";
?>