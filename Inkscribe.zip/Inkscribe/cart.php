<?php
	// the shopping cart needs sessions, to start one
	/*
		Array of session(
			cart => array (
				book_isbn (get from $_POST['book_isbn']) => number of books
			),
			items => 0,
			total_price => '0.00'
		)
	*/
	session_start();
	require_once "./functions/database_functions.php";
	require_once "./functions/cart_functions.php";

	// book_isbn got from form post method, change this place later.
	if(isset($_POST['bookisbn'])){
		$book_isbn = $_POST['bookisbn'];
	}

	if(isset($book_isbn)){
		// new iem selected
		if(!isset($_SESSION['cart'])){
			// $_SESSION['cart'] is associative array that bookisbn => qty
			$_SESSION['cart'] = array();

			$_SESSION['total_items'] = 0;
			$_SESSION['total_price'] = '0.00';
		}

		if(!isset($_SESSION['cart'][$book_isbn])){
			$_SESSION['cart'][$book_isbn] = 1;
		} elseif(isset($_POST['cart'])){
			$_SESSION['cart'][$book_isbn]++;
			unset($_POST);
		}
	}

	// if save change button is clicked , change the qty of each bookisbn
	if(isset($_POST['save_change'])){
		foreach($_SESSION['cart'] as $isbn =>$qty){
			if($_POST[$isbn] == '0'){
				unset($_SESSION['cart']["$isbn"]);
			} else {
				$_SESSION['cart']["$isbn"] = $_POST["$isbn"];
			}
		}
	}

	// print out header here
	$title = "Your shopping cart";
	require "./template/header.php";
?>




					
			
	<h4 class="fw-bolder text-center">Cart List</h4>
      <center>
        <hr class="bg-warning" style="width:5em;height:3px;opacity:1">
      </center>
<?php
	if(isset($_SESSION['cart']) && (array_count_values($_SESSION['cart']))){
		$_SESSION['total_price'] = total_price($_SESSION['cart']);
		$_SESSION['total_items'] = total_items($_SESSION['cart']);
?>
	<div class="card rounded-0 shadow">
		<div class="card-body">
			<div class="container-fluid">
				<form action="cart.php" method="post" id="cart-form">
					<table class="table">
						<tr>
							<th>Item</th>
							<th>Price</th>
							<th>Quantity</th>
							<th>Total</th>
						</tr>
						<?php
							foreach($_SESSION['cart'] as $isbn => $qty){
								$conn = db_connect();
								$book = mysqli_fetch_assoc(getBookByIsbn($conn, $isbn));
						?>
						<tr>
							<td><?php echo $book['book_title'] . " by " . $book['book_author']; ?></td>
							<td><?php echo "Rs." . $book['book_price']; ?></td>
							<td><input type="text" value="<?php echo $qty; ?>" size="2" name="<?php echo $isbn; ?>"></td>
							<td><?php echo "Rs." . $qty * $book['book_price']; ?></td>
                            <td>
                            <input type="button" class="btn btn-danger btn-sm" value="Delete" onclick="deleteItem('<?php echo $isbn; ?>')">
                            </td>
						</tr>
						<?php } ?>
						<tr>
							<th>&nbsp;</th>
							<th>&nbsp;</th>
							<th><?php echo $_SESSION['total_items']; ?></th>
							<th><?php echo "Rs." . $_SESSION['total_price']; ?></th>
						</tr>
					</table>
				</form>
			</div>
		</div>
		<div class="card-footer text-end">
			<input type="submit" class="btn btn-primary rounded-0" name="save_change" value="Save Changes" form="cart-form">
			<a href="checkout.php" class="btn btn-dark rounded-0">Go To Checkout</a> 
			<a href="books.php" class="btn btn-warning rounded-0">Continue Shopping</a>

		</div>


		
	</div>
    <script>
function deleteItem(isbn) {
    // Construct a form element
    var form = document.createElement('form');
    form.method = 'post';
    form.action = 'cart.php';
    
    // Create an input element for the delete action
    var deleteInput = document.createElement('input');
    deleteInput.type = 'hidden';
    deleteInput.name = 'delete_item';
    deleteInput.value = isbn;
    
    // Add the input element to the form
    form.appendChild(deleteInput);
    
    // Append the form to the document and submit it
    document.body.appendChild(form);
    form.submit();
}
</script>

	
<?php
	} else {
		?>
<div class="alert alert-warning rounded-0">Your cart is empty! Please add atleast 1 book to purchase first.</div>
<?php

	}
	if(isset($conn)){ mysqli_close($conn); }
    require_once "./template/footer.php";

?>

<?php

// Assuming you have a database connection established

// Function to calculate cosine similarity between a single book and all other books in the database
function calculateSimilarityWithAllBooks($bookId) {
    $conn = db_connect();
    // Get the features for the single book from the database
    $query = "SELECT book_author, book_descr, book_title, book_price FROM books WHERE book_isbn = '$bookId'";
    $result = mysqli_query($conn, $query);

    $book = mysqli_fetch_assoc($result);
    $authorName1 = $book['book_author'];
    $description1 = $book['book_descr'];
    $bookTitle1 = $book['book_title'];
    $bookPrice1 = $book['book_price'];

    // Calculate the similarity with all other books
    $similarityScores = array();

    $query = "SELECT book_isbn, book_author, book_descr, book_title, book_price FROM books WHERE book_isbn != '$bookId'";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $bookId2 = $row['book_isbn'];
        $authorName2 = $row['book_author'];
        $description2 = $row['book_descr'];
        $bookTitle2 = $row['book_title'];
        $bookPrice2 = $row['book_price'];

        // Calculate similarity based on the desired features
        $similarity = calculateSimilarity($authorName1, $authorName2, $description1, $description2, $bookTitle1, $bookTitle2, $bookPrice1, $bookPrice2);

        $similarityScores[$bookId2] = $similarity;
    }

    return $similarityScores;
}

// Function to calculate similarity based on the desired features
function calculateSimilarity($authorName1, $authorName2, $description1, $description2, $bookTitle1, $bookTitle2, $bookPrice1, $bookPrice2) {
    // You can implement own similarity calculation logic based on the desired features
    // Assign weights to each feature and compute a similarity score
    // For example, you can use a weighted sum or any other similarity algorithm

    // Calculate similarity based on the desired features
    // For example, using a weighted sum
    $weightAuthorName = 0.3;
    $weightDescription = 0.4;
    $weightBookTitle = 0.1;
    $weightBookPrice = 0.2;

    $similarity = ($weightAuthorName * calculateFeatureSimilarity($authorName1, $authorName2)) +
        ($weightDescription * calculateFeatureSimilarity($description1, $description2)) +
        ($weightBookTitle * calculateFeatureSimilarity($bookTitle1, $bookTitle2)) +
        ($weightBookPrice * calculateFeatureSimilarity($bookPrice1, $bookPrice2));

    return $similarity;
}

// Function to calculate similarity between two features
function calculateFeatureSimilarity($feature1, $feature2) {
    // You can implement your own similarity calculation logic for each feature
    // For example, you can use string similarity algorithms or other methods

    // Calculate similarity between features
    // For example, using the Jaro-Winkler distance algorithm
    $similarity = 1 - levenshtein($feature1, $feature2) / max(strlen($feature1), strlen($feature2));

    return $similarity;
}

$conn = db_connect();

$recommendedBooks = array();

if (isset($_SESSION['cart']) && $_SESSION['cart'] !== null) {
    $recommendedBooks = []; // Initialize an empty array to store recommended books

    foreach ($_SESSION['cart'] as $isbn => $qty) {
        // Get the details of the recommended book
        // Usage example:
        $bookId = $isbn; // ID of the single book

        // Call the function to calculate similarity between the single book and all other books
        $similarityScores = calculateSimilarityWithAllBooks($bookId);

        // Find the book with the highest similarity score
        $highestSimilarity = -1;
        $recommendedBookId = '';
        foreach ($similarityScores as $bookId2 => $similarity) {
            if ($similarity > $highestSimilarity) {
                $highestSimilarity = $similarity;
                $recommendedBookId = $bookId2;
            }
        }

        // Get the details of the recommended book
        $query = "SELECT book_author, book_descr, book_title, book_price, book_image FROM books WHERE book_isbn = '$recommendedBookId'";
        $result = mysqli_query($conn, $query);
        $recommendedBook = mysqli_fetch_assoc($result);

        // Add the recommended book details to the array
        $recommendedBooks[] = [
            'ISBN' => $recommendedBookId,
            'Author' => $recommendedBook['book_author'],
            'Description' => $recommendedBook['book_descr'],
            'Title' => $recommendedBook['book_title'],
            'Price' => $recommendedBook['book_price'],
            'Image' => $recommendedBook['book_image'],
            'Similarity' => $highestSimilarity
        ];
    }
}

if (isset($_POST['delete_item'])) {
    $delete_isbn = $_POST['delete_item'];

    // Check if the item exists in the cart
    if (isset($_SESSION['cart'][$delete_isbn])) {
        // Remove the item from the cart
        unset($_SESSION['cart'][$delete_isbn]);

        // Check if headers have already been sent
        if (headers_sent()) {
            // Use JavaScript to reload the page
            echo '<script>window.location.href = "cart.php";</script>';
            exit(); // Ensure that the script stops executing after the redirect
        } else {
            // Redirect using header
            header("Location: cart.php");
            exit(); // Ensure that the script stops executing after the redirect
        }
    }
}

// Sort the recommended books based on similarity (highest similarity first)
usort($recommendedBooks, function($a, $b) {
    return $b['Similarity'] <=> $a['Similarity'];
});

?>
<p class="lead text-center text-muted mt-3">List of All Recommended Books</p>
<div class="row">
    <?php
    $count = 0;
    for ($book = 0; $book < count($recommendedBooks); $book++) {
        ?>
        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 py-2 mb-2">
            <a href="book.php?bookisbn=<?php echo $recommendedBooks[$book]['ISBN']; ?>" class="card rounded-0 shadow book-item text-reset text-decoration-none">
                <div class="img-holder overflow-hidden">
                    <img class="img-top" src="./bootstrap/img/<?php echo $recommendedBooks[$book]['Image']; ?>">
                </div>
                <div class="card-body">
                    <div class="card-title fw-bolder h5 text-center"><?php echo $recommendedBooks[$book]['Title']; ?> @  Rs.<?php echo $recommendedBooks[$book]['Price']; ?> </div>
                </div>
            </a>
        </div>
        <?php
        $count++;
        if ($count >= 4) {
            $count = 0;
            break;
        }
    }
    ?>
</div>
<?php require_once "./template/footer.php"; ?>