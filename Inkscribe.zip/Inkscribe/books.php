<?php
session_start();
$count = 0;
// Connect to the database
require_once "./functions/database_functions.php";
$conn = db_connect();

// Check if a search query is provided
if (isset($_GET['q'])) {
    $search_query = $_GET['q'];

    // Query to search for books based on title
    $query = "SELECT book_isbn, book_image, book_title FROM books WHERE book_title LIKE '%$search_query%'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        echo "Can't retrieve data " . mysqli_error($conn);
        exit;
    }

    $title = "Search Results";
    require_once "./template/header.php";
} else {
    // If no search query is provided, display all books
    $query = "SELECT book_isbn, book_image, book_title FROM books";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        echo "Can't retrieve data " . mysqli_error($conn);
        exit;
    }

    $title = "List of Books";
    require_once "./template/header.php";
}
?>

<!-- Add a search form with Bootstrap classes -->
<div class="row my-3">
    <div class="col-md-6 offset-md-3">
        <form class="input-group" method="get" action="books.php">
            <input type="text" autocomplete="off" class="form-control" placeholder="Search for books" name="q">
            <div class="input-group-append">
                <button class="btn btn-warning" type="submit">Search</button>
            </div>
        </form>
    </div>
</div>

<p class="lead text-center text-muted"><?php echo isset($search_query) ? 'Search Results' : 'List of All Books'; ?></p>

<div class="row">
    <?php while ($book = mysqli_fetch_assoc($result)) { ?>
        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 py-2 mb-2">
            <a href="book.php?bookisbn=<?php echo $book['book_isbn']; ?>" class="card rounded-0 shadow book-item text-reset text-decoration-none">
                <div class="img-holder overflow-hidden">
                    <img class="img-top" src="./bootstrap/img/<?php echo $book['book_image']; ?>">
                </div>
                <div class="card-body">
                    <div class="card-title fw-bolder h5 text-center"><?= $book['book_title'] ?></div>
                </div>
            </a>
        </div>
    <?php
        
        
    } ?>
</div>

<?php
if (isset($conn)) { mysqli_close($conn); }
require_once "./template/footer.php";
?>
